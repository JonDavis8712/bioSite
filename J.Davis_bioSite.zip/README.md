# bioSite
A simple website showcasing the biography and interests of a friend

# CSD 340 Web Development with HTML and CSS

## Contributors

* Instructor: Nathan Braun
* Student: Jonathan L. Davis
